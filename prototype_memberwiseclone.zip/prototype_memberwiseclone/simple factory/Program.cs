﻿// See https://aka.ms/new-console-template for more information



using prototypepattern;

var manager = new Manager("Anurag");
var managerClone = (Manager)manager.Clone();
Console.WriteLine($"Cloned Manager::{managerClone.Name}");



var employee = new Employee("Narasimha", managerClone);
var employeeclone = (Employee)employee.Clone();
Console.WriteLine($"Employee is {employeeclone.Name} & manager is {employeeclone.Manager.Name}");

managerClone.Name = "Abhishek";
Console.WriteLine($"Employee is {employeeclone.Name} & manager is {employeeclone.Manager.Name}");

